
  export const QUESTIONS : Record<number, string> = {
    1: "Can you code in Ruby?",
    2: "Can you code in JavaScript?",
    3: "Can you code in Swift?",
    4: "Can you code in Java?",
    5: "Can you code in C#?"
};